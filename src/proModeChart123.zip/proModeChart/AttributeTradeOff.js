import React from "react";
const AttributeTradeOff = () => {
    return (
        <div>
            <h1>Attribute Trade Off</h1>
        </div>
    )
}
export default AttributeTradeOff;