import React from "react";
const AttributeComprision = () => {
    return (
        <div>
            <h1>Attribute Comprision</h1>
        </div>
    )
}
export default AttributeComprision;